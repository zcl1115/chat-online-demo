<template>
  <div class="body">
    <div class="menu">
      <img :src="logoURL">
      <span id="user_name"></span>
      <el-row class="tac">
        <el-col :span="24">
          <el-menu
                  default-active=""
                  class="el-menu-vertical-demo"
                  background-color="#F2F2F2"
                  text-color="#000000"
                  unique-opened
                  router
                  active-text-color="#000000"
          >
            <el-menu-item index="/recent_chat" @click.native="skip_chat()">
              <i class="el-icon-chat-dot-round"></i>
              <span slot="title">最近联系人</span>
            </el-menu-item>
            <el-menu-item index="/contacts" @click.native="skip_contacts()">
              <i class="el-icon-user"></i>
              <span slot="title">联系人列表</span>
            </el-menu-item>
            <el-menu-item index="/setting" @click.native="skip_setting()">
              <i class="el-icon-star-on"></i>
              <span slot="title">信息修改</span>
            </el-menu-item>
          </el-menu>
        </el-col>
      </el-row>
    </div>
    <div class="recent_chat_area">
      <div class="search_area">
        <el-input
                placeholder="搜索最近联系人"
                suffix-icon="el-icon-search">
        </el-input>
      </div>
      <div class="recent_contacts">
        <ul v-for="(people,index) in recent_contacts_list" v-bind:key="index" class="contact" :class = "isactive == index ? 'addclass' : '' " v-on:click="select_contact(people.name,people.contact,index)">
          <img :src="people.img_path" class="round_icon">
          <p>{{people.name}}</p>
          <p>{{people.contact}}</p>
        </ul>
      </div>
    </div>
    <div class="chat_area" v-if="isShow">
      <div class="friend_name">
        {{contacts}}
        {{contact_account}}
      </div>
      <!--eslint-disable-next-line-->
      <div class="message_show">
        <div class="message_box" v-for="(message, index) in messages" :key="index">
          <div v-if="message.to === contact_account && message.from === Info.account">

            <!--            <img :src="recent_contacts_list[isactive].img_path" class="contactor_avatar">-->
            <div class="btalk">
              <div class="avatar_box">
                <img :src="Info.img_path" class="contactor_avatar">
              </div>
              <span id="bsay">{{message.content}}</span>
              <br/>
              <br/>
            </div>
          </div>
          <div v-if="message.from === contact_account && message.to === Info.account">
            <div class="atalk">
              <div class="avatar_box">
                <img :src="recent_contacts_list[isactive].img_path" class="contactor_avatar">
              </div>
              <span id="asay">{{message.content}}</span>
            </div>
          </div>
        </div>
      </div>
      <div class="input_message">
        <div class="function_area">
          <i class="el-icon-picture"></i>
        </div>
        <div class="input_area">
            <input class="input" id="message" type="text"/>
        </div>
        <div class="send_area">
          <el-button type="primary" v-on:click="send_message()">发送<i class="el-icon-s-promotion el-icon--right" ></i></el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {getCookie} from "../components/cookieUtil";
  export default {
    data(){
      return {
        logoURL:require("../assets/logo.png"),
        Info:{},
        img_url:'',
        contacts:'',
        contact_account:'',
        recent_contacts_list:[],
        isShow:false,
        isactive:-1,
        messages:[],
      }
    },
    created(){
      this.init_recent_contacts();
    },
    mounted(){
      this.init();
      this.sockets.subscribe('message', (data) => {
        console.log(data);
        this.messages.push(data);
      });
      this.sockets.subscribe('login', (data) => {
        console.log(data);
        this.Info = data;
      })
    },
    sockets: {
      //不能改,建立连接自动调用connect
      connect: function() {
        //与socket.io连接后回调
        console.log("socket connected");
        this.$socket.emit('register',{'account':getCookie("user_account")});
      },
      //服务端向客户端发送login事件
      login: function(value) {
        //监听login(后端向前端emit  login的回调)
        console.log(value)
      },

    },
    methods:{
      init(){
        var lb_p=document.getElementById("user_name");
        lb_p.innerHTML = "欢迎您: " + getCookie("username");
      },
      skip_chat(){
        window.location.href="chat.html";
      },
      skip_contacts(){
        window.location.href="contacts.html";
      },
      skip_setting(){
        window.location.href="setting.html";
      },
      select_contact(name,account,index){
        this.contacts=name;
        this.contact_account=account;
        this.isShow=true;
        this.isactive=index;
      },
      init_recent_contacts(){
        var temp=getCookie("user_account");
        this.axios.post("api/chat/get_recent_list",this.qs.stringify({
          account: temp
        })).then((response)=>{
          this.recent_contacts_list=response.data;
        });
      },
      send_message(){
        console.log("send called");
        var message = document.getElementById("message").value;
        this.$socket.emit('sendMessage',{'to':this.contact_account,'message':message});
        this.messages.push({'from':getCookie("user_account"), 'to': this.contact_account, 'content':message});
      },
    }
  }
</script>

<style>
  .body{
    width: 100vw;
    height: 95vh;
  }
  .menu{
    width: 18%;
    height: 100%;
    float: left;
    background-color:#F2F2F2;
  }
  .recent_chat_area{
    background-color: #F7F7F7;
    width: 18%;
    height: 100%;
    float: left;
  }
  .search_area{
    text-align: center;
    width: 100%;
    height: 15%;
    line-height: 6;
  }
  .recent_contacts{
    width: 100%;
    height: 83%;
    overflow: auto;
    overflow-x: hidden;
  }
  .chat_area{
    width: 60%;
    height: 100%;
    float: left;
  }
  .friend_name{
    text-align: center;
    width: 100%;
    height: 6%;
    box-shadow: 0px 2px 0px 0px #F2F2F2;
  }
  .message_show{
    width: 100%;
    height: 67%;
    overflow: auto;
    overflow-x: hidden;
  }
  .input_message{
    width: 100%;
    height: 27%;
    box-shadow: 0px -2px 0px 0px #F2F2F2;
  }
  .function_area{
    width: 100%;
    height: 10%;
  }
  .input_area{
    margin-top: 2px;
    margin-bottom: 2px;
    width: 100%;
    height: 65%;
  }
  .input{
    width: 100%;
    height: 100%;
    line-height:10px;
  }
  .send_area{
    margin-top: 8px;
    text-align: right;
    float: right;
    width: 100%;
    height: 23%;
  }
  .round_icon{
    width: 40px;
    height: 40px;
    display: flex;
    border-radius: 50%;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    float: left;
    margin-left: -30px;
  }

  .contact{
    width: 100%;
    height: 60px;
  }
  p{
    margin-top: -8px;
    margin-left: 30px;
  }
  .addclass{
    background-color : white;
  }
  .message_box{
    /*width: 50%;*/
  }

  .atalk{
    overflow: hidden;
    float: none;
    margin-right: 50%;
    width: 50%;
    text-align:left;
  }
  .atalk span{
    float: left;
    padding:5px 0px 5px 10px;
    margin-left: 5%;
    width: 50%;
    display:inline-block;
    *display:inline;
    *zoom:1;
    text-align: justify;
    text-justify: newspaper;
    word-break: break-all;
    background:#F8F6F8;
    color: #000000;
    border-radius:10px;
  }
  .atalk .avatar_box{
    float: left;
    margin-left: 5%;
    width: 40px;
    height: 40px;
  }
  .atalk .contactor_avatar{
    float: left;
    width: 40px;
    height: 40px;
  }

  .btalk{
    overflow: hidden;
    float: none;
    margin-left: 50%;
    width: 50%;
    text-align:right;
  }
  .btalk span{
    float: right;
    padding:5px 10px 5px 0px;
    margin-right: 5%;
    width: 50%;
    display:inline-block;
    *display:inline;
    *zoom:1;
    text-align: right;
    text-justify: newspaper;
    word-break: break-all;
    background:#50519F;
    color: #FFFFFF;
    border-radius:10px;
  }
  .btalk .avatar_box{
    float: right;
    margin-right: 5%;
    width: 40px;
    height: 40px;
  }
  .btalk .contactor_avatar{
    float: right;
    width: 40px;
    height: 40px;
  }

</style>
