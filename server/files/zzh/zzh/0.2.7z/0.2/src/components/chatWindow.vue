<template>
    
</template>

<script>
    export default {
        name: "chatWindow"

    }
</script>

<style scoped>

</style>