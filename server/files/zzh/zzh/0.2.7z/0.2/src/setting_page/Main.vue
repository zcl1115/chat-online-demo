<template>
  <div class="body">
    <div class="menu">
      <el-row class="tac">
        <el-col :span="24">
          <el-menu
                  default-active=""
                  class="el-menu-vertical-demo"
                  background-color="#F2F2F2"
                  text-color="#000000"
                  unique-opened
                  router
                  active-text-color="#000000"
          >
            <img :src="logoURL">
            <el-menu-item index="/recent_chat" @click.native="skip_chat()">
              <i class="el-icon-chat-dot-round"></i>
              <span slot="title">最近联系人</span>
            </el-menu-item>
            <el-menu-item index="/contacts" @click.native="skip_contacts()">
              <i class="el-icon-user"></i>
              <span slot="title">联系人列表</span>
            </el-menu-item>
            <el-menu-item index="/setting" @click.native="skip_setting()">
              <i class="el-icon-star-on"></i>
              <span slot="title">信息修改</span>
            </el-menu-item>
          </el-menu>
        </el-col>
      </el-row>
    </div>
    <div class="chat_area">
      设置区域
    </div>
  </div>
</template>

<script>
  export default {
    name: "main",
    data(){
      return {
        logoURL:require("../assets/logo.png")
      }
    },
    // },
    methods:{
      skip_chat(){
        window.location.href="chat.html";
      },
      skip_contacts(){
        window.location.href="contacts.html";
      },
      skip_setting(){
        window.location.href="setting.html";
      }
    }
  }
</script>

<style>
  .body{
    width: 100vw;
    height: 100vh;
  }
  .menu{
    width: 18%;
    height: 100%;
    float: left;
    background-color:#F2F2F2;
  }
  .chat_area{
    width: 80%;
    height: 100%;
    float: left;
  }
</style>
