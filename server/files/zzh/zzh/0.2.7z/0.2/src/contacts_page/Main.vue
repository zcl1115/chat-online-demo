<template>
  <div class="body">
    <div class="menu">
      <el-row class="tac">
        <el-col :span="24">
          <el-menu
                  default-active=""
                  class="el-menu-vertical-demo"
                  background-color="#F2F2F2"
                  text-color="#000000"
                  unique-opened
                  router
                  active-text-color="#000000"
          >
            <img :src="logoURL">
            <el-menu-item index="/recent_chat" @click.native="skip_chat()">
              <i class="el-icon-chat-dot-round"></i>
              <span slot="title">最近联系人</span>
            </el-menu-item>
            <el-menu-item index="/contacts" @click.native="skip_contacts()">
              <i class="el-icon-user"></i>
              <span slot="title">联系人列表</span>
            </el-menu-item>
            <el-menu-item index="/setting" @click.native="skip_setting()">
              <i class="el-icon-star-on"></i>
              <span slot="title">信息修改</span>
            </el-menu-item>
          </el-menu>
        </el-col>
      </el-row>
    </div>

    <div class="recent_chat_area">
      <div class="search_area">
        <el-input class = "search_key"
                  placeholder="搜索最近联系人"
                  suffix-icon="el-icon-search">
        </el-input>
        <el-input class = "search_key"
                  placeholder="添加好友"
                  suffix-icon="">
        </el-input>
      </div>
      <!--eslint-disable-next-line-->
      <div class="friend" v-for="friend in friends" v-on:click="selected_account=friend.account;name_of_selected_account=friend.name">
        <!--        先不要删除本地资源格式-->
        <!--        数据库中格式为"xx/yy.img-->
        <!--        <img class="profile_photo" :src="require('../'+friend.img_path)"/>-->
        <img class="avatar" :src="friend.img_path">
        <a class="friend_name">{{ friend.name }}</a>
      </div>
    </div>
    <div class="chat_area">
      <div class="friend_name">
        {{name_of_selected_account}}
      </div>
      <div class="message_show">
        显示信息
      </div>
      <div class="input_message">
        <div class="function_area">
          功能待定
        </div>
        <div class="input_area">
          <input class="input">
        </div>
        <div class="send_area">
          <el-button type="primary">发送<i class="el-icon-s-promotion el-icon--right"></i></el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "main",
    created() {
      this.load_friends();
    },
    data(){
      return {
        logoURL:require("../assets/logo.png"),
        account:'zzh',
        friends:[],
        img_path:"",
        imgsrc:"logo",
        selected_account:'',
        name_of_selected_account:'',
        online_status:false,
      }
    },
    // },
    methods:{
      skip_chat(){
        window.location.href="chat.html";
      },
      skip_contacts(){
        window.location.href="contacts.html";
      },
      skip_setting(){
        window.location.href="setting.html";
      },
      load_friends(){
        console.log("load_friends called");
        this.axios.post("api/load_friends",this.qs.stringify({
          account: this.account,
        })).then((response)=>{
          this.friends = response.data;
        })
      },
    },
  }
</script>

<style>
  .body{
    width: 100vw;
    height: 95vh;
  }
  .menu{
    width: 18%;
    height: 100%;
    float: left;
    background-color:#F2F2F2;
  }
  .recent_chat_area{
    background-color: #F7F7F7;
    width: 18%;
    height: 100%;
    float: left;
  }
  .search_area{
    text-align: center;
    width: 100%;
    height: 15%;
    line-height: 6;
  }
  .search_key{
    float: right;
    height: 40px;
  }
  .recent_contacts{
    width: 100%;
    height: 83%;
  }
  .chat_area{
    width: 60%;
    height: 100%;
    float: left;
  }
  .friend_name{
    text-align: center;
    width: 100%;
    height: 6%;
    box-shadow: 0px 2px 0px 0px #F2F2F2;
  }
  .message_show{
    width: 100%;
    height: 67%;
  }
  .input_message{
    width: 100%;
    height: 27%;
    box-shadow: 0px -2px 0px 0px #F2F2F2;
  }
  .function_area{
    width: 100%;
    height: 10%;
  }
  .input_area{
    margin-top: 2px;
    margin-bottom: 2px;
    width: 100%;
    height: 65%;
  }
  .input{
    width: 100%;
    height: 100%;
  }
  .send_area{
    margin-top: 8px;
    text-align: right;
    float: right;
    width: 100%;
    height: 23%;
  }
  .friend{
    width: 100%;
    height: 50px;
    margin-bottom: 25px;
  }
  .avatar{
    height: 70px;
    border-radius:50%
  }
  .friend_name{
  }
</style>
