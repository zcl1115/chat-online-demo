var moment = require('moment');
var express = require('express');
var router = express.Router();
var http = require('http');
var server = http.createServer(function (req, res) {
}).listen(3001);//创建http服务

console.log('Server running ');
var io = require('socket.io').listen(server);

var online_users = {}; // records online users'socket
io.on('connection', function (socket) {
  console.log("A user connected");
  var account = null;

  // register account with socket
  socket.on('register', function (str) {
    console.log('register called: '+ str.account);
    account = str.account;
    online_users[str.account] = socket;
    console.log(online_users[str.account].id);
    db_helper.setOnline(str.account);

    console.log("online users:"+Object.keys(online_users));
    db_helper.getImgPath(account,function (img_path) {
      socket.emit("login",{'account':account, 'img_path':img_path});
    })
  });

  // sendMessage event
  socket.on('sendMessage', function (str) {
    console.log("(sendMessage) account: " + account + ' to ' +str.to + ' message: ' + str.message + 'time: ' +  moment(Date.now()).format('YYYY-MM-DD HH:mm:ss'));
    // Online
    if(str.to in online_users){
      console.log("online");
      online_users[str.to].emit('message',{'from':account, 'to': str.to, 'content':str.message, 'time':moment(Date.now()).format('YYYY-MM-DD HH:mm:ss')});
    }else{
      console.log("offline");
    }
    // Offline operation
  });

  // disconnect event
  socket.on('disconnect', function () {
    if(account != null)
    {
      db_helper.setOffline(account,function () {
        //online_users[account] = undefined;
        console.log("(disconnect) account: " + account);
      });
    }else{
      console.log("(disconnect) account: undefined");
    }
  });
});

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});
router.post('/get_recent_list', function(req, res, next) {
  db_helper.getRecentList(req.body.account, function (results) {
    res.json(results);
  });
});
module.exports = router;
